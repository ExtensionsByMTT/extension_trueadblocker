/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./node_modules/css-loader/dist/cjs.js!./src/popup/popup.css":
/*!*******************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./src/popup/popup.css ***!
  \*******************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../node_modules/css-loader/dist/runtime/cssWithMappingToString.js */ "./node_modules/css-loader/dist/runtime/cssWithMappingToString.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0___default()));
___CSS_LOADER_EXPORT___.push([module.id, "@import url(https://fonts.googleapis.com/css2?family=Open+Sans&family=Raleway&family=Roboto:wght@300&display=swap);"]);
// Module
___CSS_LOADER_EXPORT___.push([module.id, "\r\nbody{\r\n  margin: 0;\r\n  width: 375px;\r\n  height: 580px;\r\n  overflow: hidden;\r\n  font-family: 'Raleway', sans-serif;\r\n  color: #ffffff;\r\n  cursor: default;\r\n  background: #23282e;\r\n  user-select: none;\r\n  -o-user-select: none;\r\n  -moz-user-select: none;\r\n  -khtml-user-select: none;\r\n  -webkit-user-select: none;\r\n}\r\nbody::-webkit-scrollbar {\r\n  display: none;\r\n}\r\n\r\n.AdBlockerLogo {\r\n  height: 60px;\r\n  width: 60px;\r\n}\r\n.adblocker {\r\n  right: 0;\r\n  overflow-y: auto;\r\nheight: 100px;\r\n  padding: 0px;\r\n}\r\n\r\n.list {\r\n  color: white;\r\n  display: flex;\r\n  flex-direction: column;\r\n  justify-items: center;\r\n  gap: 10px;\r\n  padding-left: 12px;\r\n  line-height: 0;\r\n  position: absolute;\r\n  bottom: 50px;\r\n}\r\n.icon_text {\r\n  display: flex;\r\n  align-items: center;\r\n  justify-items: center;\r\n  gap: 20px;\r\n  line-height: 0;\r\n}\r\n.text {\r\n  font-weight: 400;\r\n  font-size: 18px;\r\n  line-height: 0;\r\n}\r\n.btn {\r\n  width: 85%;\r\n  height: 55px;\r\n  margin-left: 20px;\r\n  display: flex;\r\n  gap: 10px;\r\n  background: rgba(255, 255, 255, 0.19);\r\n  border-radius: 10px !important;\r\n}\r\n.action_btn {\r\n  margin: 6px;\r\n  padding: 7px 33px;\r\n  margin-left: 10px;\r\n  border-radius: 10px;\r\n  font-style: normal;\r\n  font-weight: 700;\r\n  font-size: 20px;\r\n  line-height: 24px;\r\n\r\n  color: #3e3e3e;\r\n}\r\n.statics_btn {\r\n  color: #d9d9d9;\r\n  font-style: normal;\r\n  font-weight: 700;\r\n  font-size: 20px;\r\n  line-height: 24px;\r\n  background-color: transparent;\r\n  margin: 6px;\r\n  padding: 7px 33px;\r\n  border-radius: 10px;\r\n}\r\n.img_size {\r\n  width: 129px;\r\n  height: 129px;\r\n  margin-left: 110px;\r\n}\r\n.text_area h3,\r\nh4 {\r\n  line-height: 0;\r\n  text-align: center;\r\n  color: white;\r\n  font-weight: 400;\r\n  font-size: 22px;\r\n}\r\n\r\n\r\n/* animated cirlce styles */\r\n.extHeading {\r\n  line-height: 0;\r\n  text-align: center;\r\n  color: white;\r\n  font-weight: 400;\r\n  padding: 0 0 10px 0;\r\n}\r\n.icons {\r\n  display: flex;\r\n  align-items: center;\r\n  gap: 10px;\r\n\r\n}\r\n.header{\r\n  height: 100px;\r\ndisplay: flex;\r\njustify-content: space-between;\r\nalign-items: center;\r\n  /* box-shadow: 0 1px 10px white; */\r\n  padding: 0px 10px 0px 10px;\r\n}\r\n\r\n.popup {\r\n  display: flex;\r\n  justify-content: center;\r\n  align-items: start;\r\n  flex-direction: column;\r\n  color: white;\r\n  position: absolute;\r\n  bottom: 40%;\r\n  padding: 0px 0px 0px 10px;\r\n  height: 75px;\r\n  }\r\n  \r\n  \r\n  .ytAds-btn{\r\n    padding: 5px 30px 5px 30px;\r\n    background: red;\r\n    color: white;\r\n    font-weight: bold;\r\n    border: none;\r\n    border-radius: 5px;\r\n  }\r\n  \r\n\r\n  /* //////////////////////loader css////////////////// */\r\n\r\n  \r\n.main{\r\n  display: flex;\r\n  justify-content: center;\r\n  align-items: center;\r\n  position: fixed;\r\n  width: 100%;\r\n  top: 258px;\r\n \r\n}\r\n.main-disconnect{\r\n \r\n    display: flex;\r\n    align-items: center;\r\n    position: absolute;\r\n    width: 100%;\r\n    box-shadow: 0 5px 10px #000;\r\n    top: 12px;\r\n}\r\n#ConnectionButton {\r\n    position: absolute;\r\n    width: 120px;\r\n    height: 120px;\r\n    align-items: center;\r\n    justify-content: center;\r\n    transition: right 0.5s ease-in-out, top ease-in-out 0.5s, width ease-in-out 0.5s, height ease-in-out 0.5s;\r\n    display: flex;\r\n    top: 0;\r\n    right: 127px;\r\n    cursor: pointer;\r\n  }\r\n  #ConnectionButton .staticOuterCircle,\r\n  #ConnectionButton .staticInnerCircle,\r\n  #ConnectionButton .staticBackground {\r\n    position: absolute;\r\n    transition: left 0.5s ease-in-out, top ease-in-out 0.5s, width ease-in-out 0.5s, height ease-in-out 0.5s;\r\n  }\r\n  #ConnectionButton .staticOuterCircle {\r\n    width: 118px;\r\n    height: 118px;\r\n    border: 1px solid;\r\n    border-radius: 200px;\r\n    left: 0;\r\n    top: 0;\r\n  }\r\n  #ConnectionButton .staticInnerCircle {\r\n    width: 110px;\r\n    height: 110px;\r\n    border: 1px solid;\r\n    border-radius: 105px;\r\n    left: 4px;\r\n    top: 4px;\r\n  }\r\n  #ConnectionButton .staticBackground {\r\n    opacity: 0.1;\r\n    width: 110px;\r\n    height: 110px;\r\n    left: 5px;\r\n    top: 5px;\r\n    border-radius: 110px;\r\n  }\r\n  #ConnectionButton.connected,\r\n  #ConnectionButton.postConnection {\r\n    width: 70px;\r\n    height: 70px;\r\n    right: 20px;\r\n    top: 11%;\r\n  }\r\n  #ConnectionButton.connected .staticOuterCircle,\r\n  #ConnectionButton.postConnection .staticOuterCircle {\r\n    width: 68px;\r\n    height: 68px;\r\n    animation: pulsing 0.7s linear 0s infinite alternate;\r\n  }\r\n  #ConnectionButton.connected .staticInnerCircle,\r\n  #ConnectionButton.postConnection .staticInnerCircle {\r\n    width: 62px;\r\n    height: 62px;\r\n    left: 3px;\r\n    top: 3px;\r\n  }\r\n  #ConnectionButton.connected .staticBackground,\r\n  #ConnectionButton.postConnection .staticBackground {\r\n    width: 64px;\r\n    height: 64px;\r\n    left: 4px;\r\n    top: 4px;\r\n  }\r\n  #ConnectionButton.connected .staticOuterCircle,\r\n  #ConnectionButton.postConnection .staticOuterCircle,\r\n  #ConnectionButton.connected .staticInnerCircle,\r\n  #ConnectionButton.postConnection .staticInnerCircle {\r\n    border-color: #40c584;\r\n  }\r\n  #ConnectionButton.connected .staticBackground,\r\n  #ConnectionButton.postConnection .staticBackground {\r\n    background: #40c584;\r\n  }\r\n  #ConnectionButton.disconnected .staticOuterCircle {\r\n    animation: pulsing 0.7s linear 0s infinite alternate;\r\n  }\r\n  #ConnectionButton.disconnected .staticOuterCircle,\r\n  #ConnectionButton.disconnected .staticInnerCircle {\r\n    border-color: red;\r\n  }\r\n  #ConnectionButton.disconnected .staticBackground {\r\n    background: red;\r\n  }\r\n  #ConnectionButton .title {\r\n    font-size: 14px;\r\n  }\r\n  #ConnectionButton.connecting .staticOuterCircle,\r\n  #ConnectionButton.disconnecting .staticOuterCircle,\r\n  #ConnectionButton.connecting .staticInnerCircle,\r\n  #ConnectionButton.disconnecting .staticInnerCircle,\r\n  #ConnectionButton.connecting .staticBackground,\r\n  #ConnectionButton.disconnecting .staticBackground {\r\n    opacity: 0;\r\n  }\r\n  #ConnectionButton.connecting .outer-layer,\r\n  #ConnectionButton.disconnecting .outer-layer,\r\n  #ConnectionButton.connecting .inner-layer,\r\n  #ConnectionButton.disconnecting .inner-layer,\r\n  #ConnectionButton.connecting .background-layer,\r\n  #ConnectionButton.disconnecting .background-layer {\r\n    width: 120px;\r\n    height: 120px;\r\n    position: absolute;\r\n  }\r\n  #ConnectionButton.connecting .outer-circle,\r\n  #ConnectionButton.disconnecting .outer-circle {\r\n    opacity: 0.5;\r\n    stroke-dasharray: 0, 1000;\r\n    animation: dash_outer 2.7s ease-in-out alternate infinite;\r\n  }\r\n  #ConnectionButton.connecting .inner-circle,\r\n  #ConnectionButton.disconnecting .inner-circle {\r\n    stroke-dasharray: 0, 1000;\r\n    animation: dash_inner 2s ease-in-out alternate infinite;\r\n  }\r\n  #ConnectionButton.connecting .outer-layer,\r\n  #ConnectionButton.disconnecting .outer-layer {\r\n    animation: rotation 1.3s infinite linear;\r\n  }\r\n  #ConnectionButton.connecting .inner-layer,\r\n  #ConnectionButton.disconnecting .inner-layer {\r\n    animation: rotation 1s infinite linear;\r\n  }\r\n  #ConnectionButton.connecting .outer-circle,\r\n  #ConnectionButton.disconnecting .outer-circle,\r\n  #ConnectionButton.connecting .inner-circle,\r\n  #ConnectionButton.disconnecting .inner-circle {\r\n    stroke: #007aff;\r\n  }\r\n  #ConnectionButton.connecting .background-circle,\r\n  #ConnectionButton.disconnecting .background-circle {\r\n    opacity: 0.1;\r\n    fill: #007aff;\r\n  }\r\n  @keyframes pulsing {\r\n    from {\r\n      opacity: 0.9;\r\n      transform: scale(1, 1);\r\n    }\r\n    to {\r\n      transform: scale(1.03, 1.03);\r\n      opacity: 0.5;\r\n    }\r\n  }\r\n  @keyframes dash_outer {\r\n    from {\r\n      stroke-dasharray: 0, 1000;\r\n    }\r\n    to {\r\n      stroke-dasharray: 377, 1000;\r\n    }\r\n  }\r\n  @keyframes dash_inner {\r\n    from {\r\n      stroke-dasharray: 0, 1000;\r\n    }\r\n    to {\r\n      stroke-dasharray: 345, 1000;\r\n    }\r\n  }\r\n  @keyframes rotation {\r\n    from {\r\n      transform: rotate(0deg);\r\n    }\r\n    to {\r\n      transform: rotate(359deg);\r\n    }\r\n  }\r\n\r\n\r\n\r\n\r\n  /* /////////////////////connecting/////////////////////////// */\r\n\r\n  @keyframes rotate-loading {\r\n    0% {transform: rotate(0deg);-ms-transform: rotate(0deg); -webkit-transform: rotate(0deg); -o-transform: rotate(0deg); -moz-transform: rotate(0deg);}\r\n    100% {transform: rotate(360deg);-ms-transform: rotate(360deg); -webkit-transform: rotate(360deg); -o-transform: rotate(360deg); -moz-transform: rotate(360deg);}\r\n    }\r\n    \r\n        @-moz-keyframes rotate-loading {\r\n            0%  {transform: rotate(0deg);-ms-transform: rotate(0deg); -webkit-transform: rotate(0deg); -o-transform: rotate(0deg); -moz-transform: rotate(0deg);}\r\n            100% {transform: rotate(360deg);-ms-transform: rotate(360deg); -webkit-transform: rotate(360deg); -o-transform: rotate(360deg); -moz-transform: rotate(360deg);}\r\n        }\r\n    \r\n        @-webkit-keyframes rotate-loading {\r\n            0%  {transform: rotate(0deg);-ms-transform: rotate(0deg); -webkit-transform: rotate(0deg); -o-transform: rotate(0deg); -moz-transform: rotate(0deg);}\r\n            100% {transform: rotate(360deg);-ms-transform: rotate(360deg); -webkit-transform: rotate(360deg); -o-transform: rotate(360deg); -moz-transform: rotate(360deg);}\r\n        }\r\n    \r\n        @-o-keyframes rotate-loading {\r\n            0%  {transform: rotate(0deg);-ms-transform: rotate(0deg); -webkit-transform: rotate(0deg); -o-transform: rotate(0deg); -moz-transform: rotate(0deg);}\r\n            100% {transform: rotate(360deg);-ms-transform: rotate(360deg); -webkit-transform: rotate(360deg); -o-transform: rotate(360deg); -moz-transform: rotate(360deg);}\r\n        }\r\n    \r\n        @keyframes rotate-loading {\r\n            0%  {transform: rotate(0deg);-ms-transform: rotate(0deg); -webkit-transform: rotate(0deg); -o-transform: rotate(0deg); -moz-transform: rotate(0deg);}\r\n            100% {transform: rotate(360deg);-ms-transform: rotate(360deg); -webkit-transform: rotate(360deg); -o-transform: rotate(360deg); -moz-transform: rotate(360deg);}\r\n        }\r\n    \r\n        @-moz-keyframes rotate-loading {\r\n            0%  {transform: rotate(0deg);-ms-transform: rotate(0deg); -webkit-transform: rotate(0deg); -o-transform: rotate(0deg); -moz-transform: rotate(0deg);}\r\n            100% {transform: rotate(360deg);-ms-transform: rotate(360deg); -webkit-transform: rotate(360deg); -o-transform: rotate(360deg); -moz-transform: rotate(360deg);}\r\n        }\r\n    \r\n        @-webkit-keyframes rotate-loading {\r\n            0%  {transform: rotate(0deg);-ms-transform: rotate(0deg); -webkit-transform: rotate(0deg); -o-transform: rotate(0deg); -moz-transform: rotate(0deg);}\r\n            100% {transform: rotate(360deg);-ms-transform: rotate(360deg); -webkit-transform: rotate(360deg); -o-transform: rotate(360deg); -moz-transform: rotate(360deg);}\r\n        }\r\n    \r\n        @-o-keyframes rotate-loading {\r\n            0%  {transform: rotate(0deg);-ms-transform: rotate(0deg); -webkit-transform: rotate(0deg); -o-transform: rotate(0deg); -moz-transform: rotate(0deg);}\r\n            100% {transform: rotate(360deg);-ms-transform: rotate(360deg); -webkit-transform: rotate(360deg); -o-transform: rotate(360deg); -moz-transform: rotate(360deg);}\r\n        }\r\n    \r\n        @keyframes loading-text-opacity {\r\n            0%  {opacity: 0}\r\n            20% {opacity: 0}\r\n            50% {opacity: 1}\r\n            100%{opacity: 0}\r\n        }\r\n    \r\n        @-moz-keyframes loading-text-opacity {\r\n            0%  {opacity: 0}\r\n            20% {opacity: 0}\r\n            50% {opacity: 1}\r\n            100%{opacity: 0}\r\n        }\r\n    \r\n        @-webkit-keyframes loading-text-opacity {\r\n            0%  {opacity: 0}\r\n            20% {opacity: 0}\r\n            50% {opacity: 1}\r\n            100%{opacity: 0}\r\n        }\r\n    \r\n        @-o-keyframes loading-text-opacity {\r\n            0%  {opacity: 0}\r\n            20% {opacity: 0}\r\n            50% {opacity: 1}\r\n            100%{opacity: 0}\r\n        }\r\n        .loading-container,\r\n        .loading {\r\n            height: 100px;\r\n            position: relative;\r\n            width: 100px;\r\n            border-radius: 100%;\r\n        }\r\n    \r\n    \r\n\r\n    \r\n        .loading {\r\n            border: 2px solid transparent;\r\n            border-color: transparent red transparent red;\r\n            -moz-animation: rotate-loading 1.5s linear 0s infinite normal;\r\n            -moz-transform-origin: 50% 50%;\r\n            -o-animation: rotate-loading 1.5s linear 0s infinite normal;\r\n            -o-transform-origin: 50% 50%;\r\n            -webkit-animation: rotate-loading 1.5s linear 0s infinite normal;\r\n            -webkit-transform-origin: 50% 50%;\r\n            animation: rotate-loading 1.5s linear 0s infinite normal;\r\n            transform-origin: 50% 50%;\r\n        }\r\n    \r\n        .loading-container:hover .loading {\r\n            border-color: transparent #E45635 transparent #E45635;\r\n        }\r\n        .loading-container:hover .loading,\r\n        .loading-container .loading {\r\n            -webkit-transition: all 0.5s ease-in-out;\r\n            -moz-transition: all 0.5s ease-in-out;\r\n            -ms-transition: all 0.5s ease-in-out;\r\n            -o-transition: all 0.5s ease-in-out;\r\n            transition: all 0.5s ease-in-out;\r\n        }\r\n    \r\n        #loading-text {\r\n            -moz-animation: loading-text-opacity 2s linear 0s infinite normal;\r\n            -o-animation: loading-text-opacity 2s linear 0s infinite normal;\r\n            -webkit-animation: loading-text-opacity 2s linear 0s infinite normal;\r\n            animation: loading-text-opacity 2s linear 0s infinite normal;\r\n            color: #ffffff;\r\n         \r\n            font-size: 10px;\r\n            font-weight: bold;\r\n            margin-top: 45px;\r\n            opacity: 0;\r\n            position: absolute;\r\n            text-align: center;\r\n            text-transform: uppercase;\r\n            top: 0;\r\n            width: 100px;\r\n        }\r\n\r\n\r\n \r\n        \r\n\r\n        .main-dis{\r\n          display: flex;\r\n          justify-content: center;\r\n          align-items: center;\r\n          position: fixed;\r\n          width: 100%;\r\n        top: 0px !important;\r\n        background-color: #63d471;\r\n        background-image: linear-gradient(360deg, #79d383 0%, #404b44 65%);\r\n        height: 100%;\r\n        }\r\n\r\n.main-connecting{\r\n  display: flex;\r\n          justify-content: center;\r\n          align-items: center;\r\n          position: fixed;\r\n          width: 100%;\r\n        top: 0px !important;\r\n        background-image: linear-gradient(360deg, #79d383 0%, #404b44 74%);\r\n    \r\n        height: 100%;\r\n}\r\n\r\n/*//////////////disconnect features////////////// */\r\n\r\n\r\n.features{\r\n  width: 100%;\r\n  height: 100%;\r\n \r\nanimation: fade-in 1.5s ease-in ;\r\n}\r\n\r\n@keyframes fade-in{\r\n  from{\r\n    opacity: 0;\r\n  }\r\n  to {\r\n    opacity: 1;\r\n  }\r\n}\r\n\r\n\r\n\r\n.features h4{\r\n  font-size: 14px !important;\r\n}\r\n\r\n\r\n.youtube,.twitch{\r\n  display: flex;\r\n  justify-content: space-between;\r\n  align-items: center;\r\n}\r\n\r\n.youtube span img{\r\n  height: 30px;\r\n  width: 30px;\r\n}\r\n.twitch span img{\r\n  height: 30px;\r\n  width: 30px;\r\n}\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n/* animated cirlce styles */\r\n.extHeading {\r\n  line-height: 0;\r\n  text-align: center;\r\n  color: white;\r\n  font-weight: 400;\r\n  font-size: 17px;\r\n\r\n\r\n}\r\n\r\n.main-container {\r\n  display: flex;\r\n  display: -webkit-flex;\r\n  align-items: center;\r\n  -webkit-align-items: center;\r\n  overflow: hidden;\r\npadding: 35px 0px 35px 0px;\r\n}\r\n.animated-main {\r\n  margin: 0px auto;\r\n  width: 200px;\r\n  height: 200px;\r\n  position: relative;\r\n \r\n\r\n}\r\n.big-circle {\r\n  height: 100%;\r\n  width: 100%;\r\n  position: relative;\r\n  border: 3px solid #efa73b;\r\n  border-radius: 50%;\r\n  display: flex;\r\n  display: -webkit-flex;\r\n  align-items: center;\r\n  -webkit-align-items: center;\r\n  justify-content: center;\r\n  -webkit-justify-content: center;\r\n  animation: Rotate 20s linear infinite;\r\n  -webkit-animation: Rotate 20s linear infinite;\r\n}\r\n.icon-block {\r\n  width: 30px;\r\n  height: 30px;\r\n  position: absolute;\r\n  border-radius: 50%;\r\n  display: flex;\r\n  display: -webkit-flex;\r\n  align-items: center;\r\n  -webkit-align-items: center;\r\n  justify-content: center;\r\n  -webkit-justify-content: center;\r\n  background-image: linear-gradient(180deg, #efa73b 0%, #efa73b 100%);\r\n  -webkit-background-image: linear-gradient(180deg, #efa73b 0%, #efa73b 100%);\r\n  /* box-shadow: 0 2px 4px 0 #efa73b; */\r\n  /* -webkit-box-shadow: 0 2px 4px 0 #efa73b; */\r\n}\r\n.icon-block img {\r\n  margin: 0px auto;\r\n  width: 86%;\r\n  animation: Rotate-reverse 20s linear infinite;\r\n  -webkit-animation: Rotate-reverse 20s linear infinite;\r\n}\r\n.icon-block:first-child {\r\n  top: 0;\r\n  left: 50%;\r\n  transform: translate(-50%, -50%);\r\n  -webkit-transform: translate(-50%, -50%);\r\n}\r\n.icon-block:nth-child(2) {\r\n  top: 50%;\r\n  right: 0;\r\n  transform: translate(50%, -50%);\r\n  -webkit-transform: translate(50%, -50%);\r\n}\r\n.icon-block:nth-child(3) {\r\n  bottom: 0;\r\n  left: 50%;\r\n  transform: translate(-50%, 50%);\r\n  -webkit-transform: translate(-50%, 50%);\r\n}\r\n.icon-block:nth-child(4) {\r\n  top: 50%;\r\n  left: 0;\r\n  transform: translate(-50%, -50%);\r\n  -webkit-transform: translate(-50%, -50%);\r\n}\r\n\r\n\r\n\r\n\r\n\r\n/* circle content */\r\n.circle {\r\n  animation: circle-rotate 20s linear infinite;\r\n  -webkit-animation: circle-rotate 20s linear infinite;\r\n  position: absolute;\r\n  top: 50%;\r\n  left: 50%;\r\n  transform: translate(-50%, -50%) rotate(45deg);\r\n  -webkit-transform: translate(-50%, -50%) rotate(45deg);\r\n  width: 75%;\r\n  height: 75%;\r\n  border: 3px solid #efa73b;\r\n  border-radius: 50%;\r\n}\r\n.circle .icon-block img {\r\n  animation: img-rotate 20s linear infinite;\r\n  -webkit-animation: img-rotate 20s linear infinite;\r\n}\r\n/* center logo */\r\n.center-logo {\r\n  position: absolute;\r\n  top: 50%;\r\n  left: 50%;\r\n  transform: translate(-50%, -50%);\r\n  -webkit-transform: translate(-50%, -50%);\r\n}\r\n.center-logo img {\r\n  max-width: 200px;\r\n}\r\n\r\n.bi-shield-fill-plus {\r\n  height: 50px;\r\n  width: 50px;\r\n  color: #efa73b;\r\n}\r\n.bi-pc,\r\n.bi-pc-display-horizontal,\r\n.bi-key,\r\n.bi-file-lock,\r\n.bi-gear-wide-connected {\r\n  color: white;\r\n}\r\n\r\n/* keyframe animation */\r\n\r\n@keyframes Rotate {\r\n  from {\r\n    transform: rotate(0deg);\r\n  }\r\n  to {\r\n    transform: rotate(360deg);\r\n  }\r\n}\r\n\r\n@-webkit-keyframes Rotate {\r\n  from {\r\n    -webkit-transform: rotate(0deg);\r\n  }\r\n  to {\r\n    -webkit-transform: rotate(360deg);\r\n  }\r\n}\r\n\r\n@keyframes Rotate-reverse {\r\n  from {\r\n    transform: rotate(360deg);\r\n  }\r\n  to {\r\n    transform: rotate(0deg);\r\n  }\r\n}\r\n\r\n@-webkit-keyframes Rotate-reverse {\r\n  from {\r\n    -webkit-transform: rotate(360deg);\r\n  }\r\n  to {\r\n    -webkit-transform: rotate(0deg);\r\n  }\r\n}\r\n\r\n@keyframes circle-rotate {\r\n  from {\r\n    transform: translate(-50%, -50%) rotate(45deg);\r\n  }\r\n  to {\r\n    transform: translate(-50%, -50%) rotate(405deg);\r\n  }\r\n}\r\n\r\n@-webkit-keyframes circle-rotate {\r\n  from {\r\n    -webkit-transform: translate(-50%, -50%) rotate(45deg);\r\n  }\r\n  to {\r\n    -webkit-transform: translate(-50%, -50%) rotate(405deg);\r\n  }\r\n}\r\n\r\n@keyframes img-rotate {\r\n  from {\r\n    transform: rotate(-45deg);\r\n  }\r\n  to {\r\n    transform: rotate(-405deg);\r\n  }\r\n}\r\n\r\n@-webkit-keyframes img-rotate {\r\n  from {\r\n    -webkit-transform: rotate(-45deg);\r\n  }\r\n  to {\r\n    -webkit-transform: rotate(-405deg);\r\n  }\r\n}", "",{"version":3,"sources":["webpack://./src/popup/popup.css"],"names":[],"mappings":";AAGA;EACE,SAAS;EACT,YAAY;EACZ,aAAa;EACb,gBAAgB;EAChB,kCAAkC;EAClC,cAAc;EACd,eAAe;EACf,mBAAmB;EACnB,iBAAiB;EACjB,oBAAoB;EACpB,sBAAsB;EACtB,wBAAwB;EACxB,yBAAyB;AAC3B;AACA;EACE,aAAa;AACf;;AAEA;EACE,YAAY;EACZ,WAAW;AACb;AACA;EACE,QAAQ;EACR,gBAAgB;AAClB,aAAa;EACX,YAAY;AACd;;AAEA;EACE,YAAY;EACZ,aAAa;EACb,sBAAsB;EACtB,qBAAqB;EACrB,SAAS;EACT,kBAAkB;EAClB,cAAc;EACd,kBAAkB;EAClB,YAAY;AACd;AACA;EACE,aAAa;EACb,mBAAmB;EACnB,qBAAqB;EACrB,SAAS;EACT,cAAc;AAChB;AACA;EACE,gBAAgB;EAChB,eAAe;EACf,cAAc;AAChB;AACA;EACE,UAAU;EACV,YAAY;EACZ,iBAAiB;EACjB,aAAa;EACb,SAAS;EACT,qCAAqC;EACrC,8BAA8B;AAChC;AACA;EACE,WAAW;EACX,iBAAiB;EACjB,iBAAiB;EACjB,mBAAmB;EACnB,kBAAkB;EAClB,gBAAgB;EAChB,eAAe;EACf,iBAAiB;;EAEjB,cAAc;AAChB;AACA;EACE,cAAc;EACd,kBAAkB;EAClB,gBAAgB;EAChB,eAAe;EACf,iBAAiB;EACjB,6BAA6B;EAC7B,WAAW;EACX,iBAAiB;EACjB,mBAAmB;AACrB;AACA;EACE,YAAY;EACZ,aAAa;EACb,kBAAkB;AACpB;AACA;;EAEE,cAAc;EACd,kBAAkB;EAClB,YAAY;EACZ,gBAAgB;EAChB,eAAe;AACjB;;;AAGA,2BAA2B;AAC3B;EACE,cAAc;EACd,kBAAkB;EAClB,YAAY;EACZ,gBAAgB;EAChB,mBAAmB;AACrB;AACA;EACE,aAAa;EACb,mBAAmB;EACnB,SAAS;;AAEX;AACA;EACE,aAAa;AACf,aAAa;AACb,8BAA8B;AAC9B,mBAAmB;EACjB,kCAAkC;EAClC,0BAA0B;AAC5B;;AAEA;EACE,aAAa;EACb,uBAAuB;EACvB,kBAAkB;EAClB,sBAAsB;EACtB,YAAY;EACZ,kBAAkB;EAClB,WAAW;EACX,yBAAyB;EACzB,YAAY;EACZ;;;EAGA;IACE,0BAA0B;IAC1B,eAAe;IACf,YAAY;IACZ,iBAAiB;IACjB,YAAY;IACZ,kBAAkB;EACpB;;;EAGA,uDAAuD;;;AAGzD;EACE,aAAa;EACb,uBAAuB;EACvB,mBAAmB;EACnB,eAAe;EACf,WAAW;EACX,UAAU;;AAEZ;AACA;;IAEI,aAAa;IACb,mBAAmB;IACnB,kBAAkB;IAClB,WAAW;IACX,2BAA2B;IAC3B,SAAS;AACb;AACA;IACI,kBAAkB;IAClB,YAAY;IACZ,aAAa;IACb,mBAAmB;IACnB,uBAAuB;IACvB,yGAAyG;IACzG,aAAa;IACb,MAAM;IACN,YAAY;IACZ,eAAe;EACjB;EACA;;;IAGE,kBAAkB;IAClB,wGAAwG;EAC1G;EACA;IACE,YAAY;IACZ,aAAa;IACb,iBAAiB;IACjB,oBAAoB;IACpB,OAAO;IACP,MAAM;EACR;EACA;IACE,YAAY;IACZ,aAAa;IACb,iBAAiB;IACjB,oBAAoB;IACpB,SAAS;IACT,QAAQ;EACV;EACA;IACE,YAAY;IACZ,YAAY;IACZ,aAAa;IACb,SAAS;IACT,QAAQ;IACR,oBAAoB;EACtB;EACA;;IAEE,WAAW;IACX,YAAY;IACZ,WAAW;IACX,QAAQ;EACV;EACA;;IAEE,WAAW;IACX,YAAY;IACZ,oDAAoD;EACtD;EACA;;IAEE,WAAW;IACX,YAAY;IACZ,SAAS;IACT,QAAQ;EACV;EACA;;IAEE,WAAW;IACX,YAAY;IACZ,SAAS;IACT,QAAQ;EACV;EACA;;;;IAIE,qBAAqB;EACvB;EACA;;IAEE,mBAAmB;EACrB;EACA;IACE,oDAAoD;EACtD;EACA;;IAEE,iBAAiB;EACnB;EACA;IACE,eAAe;EACjB;EACA;IACE,eAAe;EACjB;EACA;;;;;;IAME,UAAU;EACZ;EACA;;;;;;IAME,YAAY;IACZ,aAAa;IACb,kBAAkB;EACpB;EACA;;IAEE,YAAY;IACZ,yBAAyB;IACzB,yDAAyD;EAC3D;EACA;;IAEE,yBAAyB;IACzB,uDAAuD;EACzD;EACA;;IAEE,wCAAwC;EAC1C;EACA;;IAEE,sCAAsC;EACxC;EACA;;;;IAIE,eAAe;EACjB;EACA;;IAEE,YAAY;IACZ,aAAa;EACf;EACA;IACE;MACE,YAAY;MACZ,sBAAsB;IACxB;IACA;MACE,4BAA4B;MAC5B,YAAY;IACd;EACF;EACA;IACE;MACE,yBAAyB;IAC3B;IACA;MACE,2BAA2B;IAC7B;EACF;EACA;IACE;MACE,yBAAyB;IAC3B;IACA;MACE,2BAA2B;IAC7B;EACF;EACA;IACE;MACE,uBAAuB;IACzB;IACA;MACE,yBAAyB;IAC3B;EACF;;;;;EAKA,+DAA+D;;EAE/D;IACE,IAAI,uBAAuB,CAAC,2BAA2B,EAAE,+BAA+B,EAAE,0BAA0B,EAAE,4BAA4B,CAAC;IACnJ,MAAM,yBAAyB,CAAC,6BAA6B,EAAE,iCAAiC,EAAE,4BAA4B,EAAE,8BAA8B,CAAC;IAC/J;;QAEI;YACI,KAAK,uBAAuB,CAAC,2BAA2B,EAAE,+BAA+B,EAAE,0BAA0B,EAAE,4BAA4B,CAAC;YACpJ,MAAM,yBAAyB,CAAC,6BAA6B,EAAE,iCAAiC,EAAE,4BAA4B,EAAE,8BAA8B,CAAC;QACnK;;QAEA;YACI,KAAK,uBAAuB,CAAC,2BAA2B,EAAE,+BAA+B,EAAE,0BAA0B,EAAE,4BAA4B,CAAC;YACpJ,MAAM,yBAAyB,CAAC,6BAA6B,EAAE,iCAAiC,EAAE,4BAA4B,EAAE,8BAA8B,CAAC;QACnK;;QAEA;YACI,KAAK,uBAAuB,CAAC,2BAA2B,EAAE,+BAA+B,EAAE,0BAA0B,EAAE,4BAA4B,CAAC;YACpJ,MAAM,yBAAyB,CAAC,6BAA6B,EAAE,iCAAiC,EAAE,4BAA4B,EAAE,8BAA8B,CAAC;QACnK;;QAEA;YACI,KAAK,uBAAuB,CAAC,2BAA2B,EAAE,+BAA+B,EAAE,0BAA0B,EAAE,4BAA4B,CAAC;YACpJ,MAAM,yBAAyB,CAAC,6BAA6B,EAAE,iCAAiC,EAAE,4BAA4B,EAAE,8BAA8B,CAAC;QACnK;;QAEA;YACI,KAAK,uBAAuB,CAAC,2BAA2B,EAAE,+BAA+B,EAAE,0BAA0B,EAAE,4BAA4B,CAAC;YACpJ,MAAM,yBAAyB,CAAC,6BAA6B,EAAE,iCAAiC,EAAE,4BAA4B,EAAE,8BAA8B,CAAC;QACnK;;QAEA;YACI,KAAK,uBAAuB,CAAC,2BAA2B,EAAE,+BAA+B,EAAE,0BAA0B,EAAE,4BAA4B,CAAC;YACpJ,MAAM,yBAAyB,CAAC,6BAA6B,EAAE,iCAAiC,EAAE,4BAA4B,EAAE,8BAA8B,CAAC;QACnK;;QAEA;YACI,KAAK,uBAAuB,CAAC,2BAA2B,EAAE,+BAA+B,EAAE,0BAA0B,EAAE,4BAA4B,CAAC;YACpJ,MAAM,yBAAyB,CAAC,6BAA6B,EAAE,iCAAiC,EAAE,4BAA4B,EAAE,8BAA8B,CAAC;QACnK;;QAEA;YACI,KAAK,UAAU;YACf,KAAK,UAAU;YACf,KAAK,UAAU;YACf,KAAK,UAAU;QACnB;;QAEA;YACI,KAAK,UAAU;YACf,KAAK,UAAU;YACf,KAAK,UAAU;YACf,KAAK,UAAU;QACnB;;QAEA;YACI,KAAK,UAAU;YACf,KAAK,UAAU;YACf,KAAK,UAAU;YACf,KAAK,UAAU;QACnB;;QAEA;YACI,KAAK,UAAU;YACf,KAAK,UAAU;YACf,KAAK,UAAU;YACf,KAAK,UAAU;QACnB;QACA;;YAEI,aAAa;YACb,kBAAkB;YAClB,YAAY;YACZ,mBAAmB;QACvB;;;;;QAKA;YACI,6BAA6B;YAC7B,6CAA6C;YAC7C,6DAA6D;YAC7D,8BAA8B;YAC9B,2DAA2D;YAC3D,4BAA4B;YAC5B,gEAAgE;YAChE,iCAAiC;YACjC,wDAAwD;YACxD,yBAAyB;QAC7B;;QAEA;YACI,qDAAqD;QACzD;QACA;;YAEI,wCAAwC;YACxC,qCAAqC;YACrC,oCAAoC;YACpC,mCAAmC;YACnC,gCAAgC;QACpC;;QAEA;YACI,iEAAiE;YACjE,+DAA+D;YAC/D,oEAAoE;YACpE,4DAA4D;YAC5D,cAAc;;YAEd,eAAe;YACf,iBAAiB;YACjB,gBAAgB;YAChB,UAAU;YACV,kBAAkB;YAClB,kBAAkB;YAClB,yBAAyB;YACzB,MAAM;YACN,YAAY;QAChB;;;;;;QAMA;UACE,aAAa;UACb,uBAAuB;UACvB,mBAAmB;UACnB,eAAe;UACf,WAAW;QACb,mBAAmB;QACnB,yBAAyB;QACzB,kEAAkE;QAClE,YAAY;QACZ;;AAER;EACE,aAAa;UACL,uBAAuB;UACvB,mBAAmB;UACnB,eAAe;UACf,WAAW;QACb,mBAAmB;QACnB,kEAAkE;;QAElE,YAAY;AACpB;;AAEA,mDAAmD;;;AAGnD;EACE,WAAW;EACX,YAAY;;AAEd,gCAAgC;AAChC;;AAEA;EACE;IACE,UAAU;EACZ;EACA;IACE,UAAU;EACZ;AACF;;;;AAIA;EACE,0BAA0B;AAC5B;;;AAGA;EACE,aAAa;EACb,8BAA8B;EAC9B,mBAAmB;AACrB;;AAEA;EACE,YAAY;EACZ,WAAW;AACb;AACA;EACE,YAAY;EACZ,WAAW;AACb;;;;;;;;;;AAUA,2BAA2B;AAC3B;EACE,cAAc;EACd,kBAAkB;EAClB,YAAY;EACZ,gBAAgB;EAChB,eAAe;;;AAGjB;;AAEA;EACE,aAAa;EACb,qBAAqB;EACrB,mBAAmB;EACnB,2BAA2B;EAC3B,gBAAgB;AAClB,0BAA0B;AAC1B;AACA;EACE,gBAAgB;EAChB,YAAY;EACZ,aAAa;EACb,kBAAkB;;;AAGpB;AACA;EACE,YAAY;EACZ,WAAW;EACX,kBAAkB;EAClB,yBAAyB;EACzB,kBAAkB;EAClB,aAAa;EACb,qBAAqB;EACrB,mBAAmB;EACnB,2BAA2B;EAC3B,uBAAuB;EACvB,+BAA+B;EAC/B,qCAAqC;EACrC,6CAA6C;AAC/C;AACA;EACE,WAAW;EACX,YAAY;EACZ,kBAAkB;EAClB,kBAAkB;EAClB,aAAa;EACb,qBAAqB;EACrB,mBAAmB;EACnB,2BAA2B;EAC3B,uBAAuB;EACvB,+BAA+B;EAC/B,mEAAmE;EACnE,2EAA2E;EAC3E,qCAAqC;EACrC,6CAA6C;AAC/C;AACA;EACE,gBAAgB;EAChB,UAAU;EACV,6CAA6C;EAC7C,qDAAqD;AACvD;AACA;EACE,MAAM;EACN,SAAS;EACT,gCAAgC;EAChC,wCAAwC;AAC1C;AACA;EACE,QAAQ;EACR,QAAQ;EACR,+BAA+B;EAC/B,uCAAuC;AACzC;AACA;EACE,SAAS;EACT,SAAS;EACT,+BAA+B;EAC/B,uCAAuC;AACzC;AACA;EACE,QAAQ;EACR,OAAO;EACP,gCAAgC;EAChC,wCAAwC;AAC1C;;;;;;AAMA,mBAAmB;AACnB;EACE,4CAA4C;EAC5C,oDAAoD;EACpD,kBAAkB;EAClB,QAAQ;EACR,SAAS;EACT,8CAA8C;EAC9C,sDAAsD;EACtD,UAAU;EACV,WAAW;EACX,yBAAyB;EACzB,kBAAkB;AACpB;AACA;EACE,yCAAyC;EACzC,iDAAiD;AACnD;AACA,gBAAgB;AAChB;EACE,kBAAkB;EAClB,QAAQ;EACR,SAAS;EACT,gCAAgC;EAChC,wCAAwC;AAC1C;AACA;EACE,gBAAgB;AAClB;;AAEA;EACE,YAAY;EACZ,WAAW;EACX,cAAc;AAChB;AACA;;;;;EAKE,YAAY;AACd;;AAEA,uBAAuB;;AAEvB;EACE;IACE,uBAAuB;EACzB;EACA;IACE,yBAAyB;EAC3B;AACF;;AAEA;EACE;IACE,+BAA+B;EACjC;EACA;IACE,iCAAiC;EACnC;AACF;;AAEA;EACE;IACE,yBAAyB;EAC3B;EACA;IACE,uBAAuB;EACzB;AACF;;AAEA;EACE;IACE,iCAAiC;EACnC;EACA;IACE,+BAA+B;EACjC;AACF;;AAEA;EACE;IACE,8CAA8C;EAChD;EACA;IACE,+CAA+C;EACjD;AACF;;AAEA;EACE;IACE,sDAAsD;EACxD;EACA;IACE,uDAAuD;EACzD;AACF;;AAEA;EACE;IACE,yBAAyB;EAC3B;EACA;IACE,0BAA0B;EAC5B;AACF;;AAEA;EACE;IACE,iCAAiC;EACnC;EACA;IACE,kCAAkC;EACpC;AACF","sourcesContent":["\r\n@import url('https://fonts.googleapis.com/css2?family=Open+Sans&family=Raleway&family=Roboto:wght@300&display=swap');\r\n\r\nbody{\r\n  margin: 0;\r\n  width: 375px;\r\n  height: 580px;\r\n  overflow: hidden;\r\n  font-family: 'Raleway', sans-serif;\r\n  color: #ffffff;\r\n  cursor: default;\r\n  background: #23282e;\r\n  user-select: none;\r\n  -o-user-select: none;\r\n  -moz-user-select: none;\r\n  -khtml-user-select: none;\r\n  -webkit-user-select: none;\r\n}\r\nbody::-webkit-scrollbar {\r\n  display: none;\r\n}\r\n\r\n.AdBlockerLogo {\r\n  height: 60px;\r\n  width: 60px;\r\n}\r\n.adblocker {\r\n  right: 0;\r\n  overflow-y: auto;\r\nheight: 100px;\r\n  padding: 0px;\r\n}\r\n\r\n.list {\r\n  color: white;\r\n  display: flex;\r\n  flex-direction: column;\r\n  justify-items: center;\r\n  gap: 10px;\r\n  padding-left: 12px;\r\n  line-height: 0;\r\n  position: absolute;\r\n  bottom: 50px;\r\n}\r\n.icon_text {\r\n  display: flex;\r\n  align-items: center;\r\n  justify-items: center;\r\n  gap: 20px;\r\n  line-height: 0;\r\n}\r\n.text {\r\n  font-weight: 400;\r\n  font-size: 18px;\r\n  line-height: 0;\r\n}\r\n.btn {\r\n  width: 85%;\r\n  height: 55px;\r\n  margin-left: 20px;\r\n  display: flex;\r\n  gap: 10px;\r\n  background: rgba(255, 255, 255, 0.19);\r\n  border-radius: 10px !important;\r\n}\r\n.action_btn {\r\n  margin: 6px;\r\n  padding: 7px 33px;\r\n  margin-left: 10px;\r\n  border-radius: 10px;\r\n  font-style: normal;\r\n  font-weight: 700;\r\n  font-size: 20px;\r\n  line-height: 24px;\r\n\r\n  color: #3e3e3e;\r\n}\r\n.statics_btn {\r\n  color: #d9d9d9;\r\n  font-style: normal;\r\n  font-weight: 700;\r\n  font-size: 20px;\r\n  line-height: 24px;\r\n  background-color: transparent;\r\n  margin: 6px;\r\n  padding: 7px 33px;\r\n  border-radius: 10px;\r\n}\r\n.img_size {\r\n  width: 129px;\r\n  height: 129px;\r\n  margin-left: 110px;\r\n}\r\n.text_area h3,\r\nh4 {\r\n  line-height: 0;\r\n  text-align: center;\r\n  color: white;\r\n  font-weight: 400;\r\n  font-size: 22px;\r\n}\r\n\r\n\r\n/* animated cirlce styles */\r\n.extHeading {\r\n  line-height: 0;\r\n  text-align: center;\r\n  color: white;\r\n  font-weight: 400;\r\n  padding: 0 0 10px 0;\r\n}\r\n.icons {\r\n  display: flex;\r\n  align-items: center;\r\n  gap: 10px;\r\n\r\n}\r\n.header{\r\n  height: 100px;\r\ndisplay: flex;\r\njustify-content: space-between;\r\nalign-items: center;\r\n  /* box-shadow: 0 1px 10px white; */\r\n  padding: 0px 10px 0px 10px;\r\n}\r\n\r\n.popup {\r\n  display: flex;\r\n  justify-content: center;\r\n  align-items: start;\r\n  flex-direction: column;\r\n  color: white;\r\n  position: absolute;\r\n  bottom: 40%;\r\n  padding: 0px 0px 0px 10px;\r\n  height: 75px;\r\n  }\r\n  \r\n  \r\n  .ytAds-btn{\r\n    padding: 5px 30px 5px 30px;\r\n    background: red;\r\n    color: white;\r\n    font-weight: bold;\r\n    border: none;\r\n    border-radius: 5px;\r\n  }\r\n  \r\n\r\n  /* //////////////////////loader css////////////////// */\r\n\r\n  \r\n.main{\r\n  display: flex;\r\n  justify-content: center;\r\n  align-items: center;\r\n  position: fixed;\r\n  width: 100%;\r\n  top: 258px;\r\n \r\n}\r\n.main-disconnect{\r\n \r\n    display: flex;\r\n    align-items: center;\r\n    position: absolute;\r\n    width: 100%;\r\n    box-shadow: 0 5px 10px #000;\r\n    top: 12px;\r\n}\r\n#ConnectionButton {\r\n    position: absolute;\r\n    width: 120px;\r\n    height: 120px;\r\n    align-items: center;\r\n    justify-content: center;\r\n    transition: right 0.5s ease-in-out, top ease-in-out 0.5s, width ease-in-out 0.5s, height ease-in-out 0.5s;\r\n    display: flex;\r\n    top: 0;\r\n    right: 127px;\r\n    cursor: pointer;\r\n  }\r\n  #ConnectionButton .staticOuterCircle,\r\n  #ConnectionButton .staticInnerCircle,\r\n  #ConnectionButton .staticBackground {\r\n    position: absolute;\r\n    transition: left 0.5s ease-in-out, top ease-in-out 0.5s, width ease-in-out 0.5s, height ease-in-out 0.5s;\r\n  }\r\n  #ConnectionButton .staticOuterCircle {\r\n    width: 118px;\r\n    height: 118px;\r\n    border: 1px solid;\r\n    border-radius: 200px;\r\n    left: 0;\r\n    top: 0;\r\n  }\r\n  #ConnectionButton .staticInnerCircle {\r\n    width: 110px;\r\n    height: 110px;\r\n    border: 1px solid;\r\n    border-radius: 105px;\r\n    left: 4px;\r\n    top: 4px;\r\n  }\r\n  #ConnectionButton .staticBackground {\r\n    opacity: 0.1;\r\n    width: 110px;\r\n    height: 110px;\r\n    left: 5px;\r\n    top: 5px;\r\n    border-radius: 110px;\r\n  }\r\n  #ConnectionButton.connected,\r\n  #ConnectionButton.postConnection {\r\n    width: 70px;\r\n    height: 70px;\r\n    right: 20px;\r\n    top: 11%;\r\n  }\r\n  #ConnectionButton.connected .staticOuterCircle,\r\n  #ConnectionButton.postConnection .staticOuterCircle {\r\n    width: 68px;\r\n    height: 68px;\r\n    animation: pulsing 0.7s linear 0s infinite alternate;\r\n  }\r\n  #ConnectionButton.connected .staticInnerCircle,\r\n  #ConnectionButton.postConnection .staticInnerCircle {\r\n    width: 62px;\r\n    height: 62px;\r\n    left: 3px;\r\n    top: 3px;\r\n  }\r\n  #ConnectionButton.connected .staticBackground,\r\n  #ConnectionButton.postConnection .staticBackground {\r\n    width: 64px;\r\n    height: 64px;\r\n    left: 4px;\r\n    top: 4px;\r\n  }\r\n  #ConnectionButton.connected .staticOuterCircle,\r\n  #ConnectionButton.postConnection .staticOuterCircle,\r\n  #ConnectionButton.connected .staticInnerCircle,\r\n  #ConnectionButton.postConnection .staticInnerCircle {\r\n    border-color: #40c584;\r\n  }\r\n  #ConnectionButton.connected .staticBackground,\r\n  #ConnectionButton.postConnection .staticBackground {\r\n    background: #40c584;\r\n  }\r\n  #ConnectionButton.disconnected .staticOuterCircle {\r\n    animation: pulsing 0.7s linear 0s infinite alternate;\r\n  }\r\n  #ConnectionButton.disconnected .staticOuterCircle,\r\n  #ConnectionButton.disconnected .staticInnerCircle {\r\n    border-color: red;\r\n  }\r\n  #ConnectionButton.disconnected .staticBackground {\r\n    background: red;\r\n  }\r\n  #ConnectionButton .title {\r\n    font-size: 14px;\r\n  }\r\n  #ConnectionButton.connecting .staticOuterCircle,\r\n  #ConnectionButton.disconnecting .staticOuterCircle,\r\n  #ConnectionButton.connecting .staticInnerCircle,\r\n  #ConnectionButton.disconnecting .staticInnerCircle,\r\n  #ConnectionButton.connecting .staticBackground,\r\n  #ConnectionButton.disconnecting .staticBackground {\r\n    opacity: 0;\r\n  }\r\n  #ConnectionButton.connecting .outer-layer,\r\n  #ConnectionButton.disconnecting .outer-layer,\r\n  #ConnectionButton.connecting .inner-layer,\r\n  #ConnectionButton.disconnecting .inner-layer,\r\n  #ConnectionButton.connecting .background-layer,\r\n  #ConnectionButton.disconnecting .background-layer {\r\n    width: 120px;\r\n    height: 120px;\r\n    position: absolute;\r\n  }\r\n  #ConnectionButton.connecting .outer-circle,\r\n  #ConnectionButton.disconnecting .outer-circle {\r\n    opacity: 0.5;\r\n    stroke-dasharray: 0, 1000;\r\n    animation: dash_outer 2.7s ease-in-out alternate infinite;\r\n  }\r\n  #ConnectionButton.connecting .inner-circle,\r\n  #ConnectionButton.disconnecting .inner-circle {\r\n    stroke-dasharray: 0, 1000;\r\n    animation: dash_inner 2s ease-in-out alternate infinite;\r\n  }\r\n  #ConnectionButton.connecting .outer-layer,\r\n  #ConnectionButton.disconnecting .outer-layer {\r\n    animation: rotation 1.3s infinite linear;\r\n  }\r\n  #ConnectionButton.connecting .inner-layer,\r\n  #ConnectionButton.disconnecting .inner-layer {\r\n    animation: rotation 1s infinite linear;\r\n  }\r\n  #ConnectionButton.connecting .outer-circle,\r\n  #ConnectionButton.disconnecting .outer-circle,\r\n  #ConnectionButton.connecting .inner-circle,\r\n  #ConnectionButton.disconnecting .inner-circle {\r\n    stroke: #007aff;\r\n  }\r\n  #ConnectionButton.connecting .background-circle,\r\n  #ConnectionButton.disconnecting .background-circle {\r\n    opacity: 0.1;\r\n    fill: #007aff;\r\n  }\r\n  @keyframes pulsing {\r\n    from {\r\n      opacity: 0.9;\r\n      transform: scale(1, 1);\r\n    }\r\n    to {\r\n      transform: scale(1.03, 1.03);\r\n      opacity: 0.5;\r\n    }\r\n  }\r\n  @keyframes dash_outer {\r\n    from {\r\n      stroke-dasharray: 0, 1000;\r\n    }\r\n    to {\r\n      stroke-dasharray: 377, 1000;\r\n    }\r\n  }\r\n  @keyframes dash_inner {\r\n    from {\r\n      stroke-dasharray: 0, 1000;\r\n    }\r\n    to {\r\n      stroke-dasharray: 345, 1000;\r\n    }\r\n  }\r\n  @keyframes rotation {\r\n    from {\r\n      transform: rotate(0deg);\r\n    }\r\n    to {\r\n      transform: rotate(359deg);\r\n    }\r\n  }\r\n\r\n\r\n\r\n\r\n  /* /////////////////////connecting/////////////////////////// */\r\n\r\n  @keyframes rotate-loading {\r\n    0% {transform: rotate(0deg);-ms-transform: rotate(0deg); -webkit-transform: rotate(0deg); -o-transform: rotate(0deg); -moz-transform: rotate(0deg);}\r\n    100% {transform: rotate(360deg);-ms-transform: rotate(360deg); -webkit-transform: rotate(360deg); -o-transform: rotate(360deg); -moz-transform: rotate(360deg);}\r\n    }\r\n    \r\n        @-moz-keyframes rotate-loading {\r\n            0%  {transform: rotate(0deg);-ms-transform: rotate(0deg); -webkit-transform: rotate(0deg); -o-transform: rotate(0deg); -moz-transform: rotate(0deg);}\r\n            100% {transform: rotate(360deg);-ms-transform: rotate(360deg); -webkit-transform: rotate(360deg); -o-transform: rotate(360deg); -moz-transform: rotate(360deg);}\r\n        }\r\n    \r\n        @-webkit-keyframes rotate-loading {\r\n            0%  {transform: rotate(0deg);-ms-transform: rotate(0deg); -webkit-transform: rotate(0deg); -o-transform: rotate(0deg); -moz-transform: rotate(0deg);}\r\n            100% {transform: rotate(360deg);-ms-transform: rotate(360deg); -webkit-transform: rotate(360deg); -o-transform: rotate(360deg); -moz-transform: rotate(360deg);}\r\n        }\r\n    \r\n        @-o-keyframes rotate-loading {\r\n            0%  {transform: rotate(0deg);-ms-transform: rotate(0deg); -webkit-transform: rotate(0deg); -o-transform: rotate(0deg); -moz-transform: rotate(0deg);}\r\n            100% {transform: rotate(360deg);-ms-transform: rotate(360deg); -webkit-transform: rotate(360deg); -o-transform: rotate(360deg); -moz-transform: rotate(360deg);}\r\n        }\r\n    \r\n        @keyframes rotate-loading {\r\n            0%  {transform: rotate(0deg);-ms-transform: rotate(0deg); -webkit-transform: rotate(0deg); -o-transform: rotate(0deg); -moz-transform: rotate(0deg);}\r\n            100% {transform: rotate(360deg);-ms-transform: rotate(360deg); -webkit-transform: rotate(360deg); -o-transform: rotate(360deg); -moz-transform: rotate(360deg);}\r\n        }\r\n    \r\n        @-moz-keyframes rotate-loading {\r\n            0%  {transform: rotate(0deg);-ms-transform: rotate(0deg); -webkit-transform: rotate(0deg); -o-transform: rotate(0deg); -moz-transform: rotate(0deg);}\r\n            100% {transform: rotate(360deg);-ms-transform: rotate(360deg); -webkit-transform: rotate(360deg); -o-transform: rotate(360deg); -moz-transform: rotate(360deg);}\r\n        }\r\n    \r\n        @-webkit-keyframes rotate-loading {\r\n            0%  {transform: rotate(0deg);-ms-transform: rotate(0deg); -webkit-transform: rotate(0deg); -o-transform: rotate(0deg); -moz-transform: rotate(0deg);}\r\n            100% {transform: rotate(360deg);-ms-transform: rotate(360deg); -webkit-transform: rotate(360deg); -o-transform: rotate(360deg); -moz-transform: rotate(360deg);}\r\n        }\r\n    \r\n        @-o-keyframes rotate-loading {\r\n            0%  {transform: rotate(0deg);-ms-transform: rotate(0deg); -webkit-transform: rotate(0deg); -o-transform: rotate(0deg); -moz-transform: rotate(0deg);}\r\n            100% {transform: rotate(360deg);-ms-transform: rotate(360deg); -webkit-transform: rotate(360deg); -o-transform: rotate(360deg); -moz-transform: rotate(360deg);}\r\n        }\r\n    \r\n        @keyframes loading-text-opacity {\r\n            0%  {opacity: 0}\r\n            20% {opacity: 0}\r\n            50% {opacity: 1}\r\n            100%{opacity: 0}\r\n        }\r\n    \r\n        @-moz-keyframes loading-text-opacity {\r\n            0%  {opacity: 0}\r\n            20% {opacity: 0}\r\n            50% {opacity: 1}\r\n            100%{opacity: 0}\r\n        }\r\n    \r\n        @-webkit-keyframes loading-text-opacity {\r\n            0%  {opacity: 0}\r\n            20% {opacity: 0}\r\n            50% {opacity: 1}\r\n            100%{opacity: 0}\r\n        }\r\n    \r\n        @-o-keyframes loading-text-opacity {\r\n            0%  {opacity: 0}\r\n            20% {opacity: 0}\r\n            50% {opacity: 1}\r\n            100%{opacity: 0}\r\n        }\r\n        .loading-container,\r\n        .loading {\r\n            height: 100px;\r\n            position: relative;\r\n            width: 100px;\r\n            border-radius: 100%;\r\n        }\r\n    \r\n    \r\n\r\n    \r\n        .loading {\r\n            border: 2px solid transparent;\r\n            border-color: transparent red transparent red;\r\n            -moz-animation: rotate-loading 1.5s linear 0s infinite normal;\r\n            -moz-transform-origin: 50% 50%;\r\n            -o-animation: rotate-loading 1.5s linear 0s infinite normal;\r\n            -o-transform-origin: 50% 50%;\r\n            -webkit-animation: rotate-loading 1.5s linear 0s infinite normal;\r\n            -webkit-transform-origin: 50% 50%;\r\n            animation: rotate-loading 1.5s linear 0s infinite normal;\r\n            transform-origin: 50% 50%;\r\n        }\r\n    \r\n        .loading-container:hover .loading {\r\n            border-color: transparent #E45635 transparent #E45635;\r\n        }\r\n        .loading-container:hover .loading,\r\n        .loading-container .loading {\r\n            -webkit-transition: all 0.5s ease-in-out;\r\n            -moz-transition: all 0.5s ease-in-out;\r\n            -ms-transition: all 0.5s ease-in-out;\r\n            -o-transition: all 0.5s ease-in-out;\r\n            transition: all 0.5s ease-in-out;\r\n        }\r\n    \r\n        #loading-text {\r\n            -moz-animation: loading-text-opacity 2s linear 0s infinite normal;\r\n            -o-animation: loading-text-opacity 2s linear 0s infinite normal;\r\n            -webkit-animation: loading-text-opacity 2s linear 0s infinite normal;\r\n            animation: loading-text-opacity 2s linear 0s infinite normal;\r\n            color: #ffffff;\r\n         \r\n            font-size: 10px;\r\n            font-weight: bold;\r\n            margin-top: 45px;\r\n            opacity: 0;\r\n            position: absolute;\r\n            text-align: center;\r\n            text-transform: uppercase;\r\n            top: 0;\r\n            width: 100px;\r\n        }\r\n\r\n\r\n \r\n        \r\n\r\n        .main-dis{\r\n          display: flex;\r\n          justify-content: center;\r\n          align-items: center;\r\n          position: fixed;\r\n          width: 100%;\r\n        top: 0px !important;\r\n        background-color: #63d471;\r\n        background-image: linear-gradient(360deg, #79d383 0%, #404b44 65%);\r\n        height: 100%;\r\n        }\r\n\r\n.main-connecting{\r\n  display: flex;\r\n          justify-content: center;\r\n          align-items: center;\r\n          position: fixed;\r\n          width: 100%;\r\n        top: 0px !important;\r\n        background-image: linear-gradient(360deg, #79d383 0%, #404b44 74%);\r\n    \r\n        height: 100%;\r\n}\r\n\r\n/*//////////////disconnect features////////////// */\r\n\r\n\r\n.features{\r\n  width: 100%;\r\n  height: 100%;\r\n \r\nanimation: fade-in 1.5s ease-in ;\r\n}\r\n\r\n@keyframes fade-in{\r\n  from{\r\n    opacity: 0;\r\n  }\r\n  to {\r\n    opacity: 1;\r\n  }\r\n}\r\n\r\n\r\n\r\n.features h4{\r\n  font-size: 14px !important;\r\n}\r\n\r\n\r\n.youtube,.twitch{\r\n  display: flex;\r\n  justify-content: space-between;\r\n  align-items: center;\r\n}\r\n\r\n.youtube span img{\r\n  height: 30px;\r\n  width: 30px;\r\n}\r\n.twitch span img{\r\n  height: 30px;\r\n  width: 30px;\r\n}\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n/* animated cirlce styles */\r\n.extHeading {\r\n  line-height: 0;\r\n  text-align: center;\r\n  color: white;\r\n  font-weight: 400;\r\n  font-size: 17px;\r\n\r\n\r\n}\r\n\r\n.main-container {\r\n  display: flex;\r\n  display: -webkit-flex;\r\n  align-items: center;\r\n  -webkit-align-items: center;\r\n  overflow: hidden;\r\npadding: 35px 0px 35px 0px;\r\n}\r\n.animated-main {\r\n  margin: 0px auto;\r\n  width: 200px;\r\n  height: 200px;\r\n  position: relative;\r\n \r\n\r\n}\r\n.big-circle {\r\n  height: 100%;\r\n  width: 100%;\r\n  position: relative;\r\n  border: 3px solid #efa73b;\r\n  border-radius: 50%;\r\n  display: flex;\r\n  display: -webkit-flex;\r\n  align-items: center;\r\n  -webkit-align-items: center;\r\n  justify-content: center;\r\n  -webkit-justify-content: center;\r\n  animation: Rotate 20s linear infinite;\r\n  -webkit-animation: Rotate 20s linear infinite;\r\n}\r\n.icon-block {\r\n  width: 30px;\r\n  height: 30px;\r\n  position: absolute;\r\n  border-radius: 50%;\r\n  display: flex;\r\n  display: -webkit-flex;\r\n  align-items: center;\r\n  -webkit-align-items: center;\r\n  justify-content: center;\r\n  -webkit-justify-content: center;\r\n  background-image: linear-gradient(180deg, #efa73b 0%, #efa73b 100%);\r\n  -webkit-background-image: linear-gradient(180deg, #efa73b 0%, #efa73b 100%);\r\n  /* box-shadow: 0 2px 4px 0 #efa73b; */\r\n  /* -webkit-box-shadow: 0 2px 4px 0 #efa73b; */\r\n}\r\n.icon-block img {\r\n  margin: 0px auto;\r\n  width: 86%;\r\n  animation: Rotate-reverse 20s linear infinite;\r\n  -webkit-animation: Rotate-reverse 20s linear infinite;\r\n}\r\n.icon-block:first-child {\r\n  top: 0;\r\n  left: 50%;\r\n  transform: translate(-50%, -50%);\r\n  -webkit-transform: translate(-50%, -50%);\r\n}\r\n.icon-block:nth-child(2) {\r\n  top: 50%;\r\n  right: 0;\r\n  transform: translate(50%, -50%);\r\n  -webkit-transform: translate(50%, -50%);\r\n}\r\n.icon-block:nth-child(3) {\r\n  bottom: 0;\r\n  left: 50%;\r\n  transform: translate(-50%, 50%);\r\n  -webkit-transform: translate(-50%, 50%);\r\n}\r\n.icon-block:nth-child(4) {\r\n  top: 50%;\r\n  left: 0;\r\n  transform: translate(-50%, -50%);\r\n  -webkit-transform: translate(-50%, -50%);\r\n}\r\n\r\n\r\n\r\n\r\n\r\n/* circle content */\r\n.circle {\r\n  animation: circle-rotate 20s linear infinite;\r\n  -webkit-animation: circle-rotate 20s linear infinite;\r\n  position: absolute;\r\n  top: 50%;\r\n  left: 50%;\r\n  transform: translate(-50%, -50%) rotate(45deg);\r\n  -webkit-transform: translate(-50%, -50%) rotate(45deg);\r\n  width: 75%;\r\n  height: 75%;\r\n  border: 3px solid #efa73b;\r\n  border-radius: 50%;\r\n}\r\n.circle .icon-block img {\r\n  animation: img-rotate 20s linear infinite;\r\n  -webkit-animation: img-rotate 20s linear infinite;\r\n}\r\n/* center logo */\r\n.center-logo {\r\n  position: absolute;\r\n  top: 50%;\r\n  left: 50%;\r\n  transform: translate(-50%, -50%);\r\n  -webkit-transform: translate(-50%, -50%);\r\n}\r\n.center-logo img {\r\n  max-width: 200px;\r\n}\r\n\r\n.bi-shield-fill-plus {\r\n  height: 50px;\r\n  width: 50px;\r\n  color: #efa73b;\r\n}\r\n.bi-pc,\r\n.bi-pc-display-horizontal,\r\n.bi-key,\r\n.bi-file-lock,\r\n.bi-gear-wide-connected {\r\n  color: white;\r\n}\r\n\r\n/* keyframe animation */\r\n\r\n@keyframes Rotate {\r\n  from {\r\n    transform: rotate(0deg);\r\n  }\r\n  to {\r\n    transform: rotate(360deg);\r\n  }\r\n}\r\n\r\n@-webkit-keyframes Rotate {\r\n  from {\r\n    -webkit-transform: rotate(0deg);\r\n  }\r\n  to {\r\n    -webkit-transform: rotate(360deg);\r\n  }\r\n}\r\n\r\n@keyframes Rotate-reverse {\r\n  from {\r\n    transform: rotate(360deg);\r\n  }\r\n  to {\r\n    transform: rotate(0deg);\r\n  }\r\n}\r\n\r\n@-webkit-keyframes Rotate-reverse {\r\n  from {\r\n    -webkit-transform: rotate(360deg);\r\n  }\r\n  to {\r\n    -webkit-transform: rotate(0deg);\r\n  }\r\n}\r\n\r\n@keyframes circle-rotate {\r\n  from {\r\n    transform: translate(-50%, -50%) rotate(45deg);\r\n  }\r\n  to {\r\n    transform: translate(-50%, -50%) rotate(405deg);\r\n  }\r\n}\r\n\r\n@-webkit-keyframes circle-rotate {\r\n  from {\r\n    -webkit-transform: translate(-50%, -50%) rotate(45deg);\r\n  }\r\n  to {\r\n    -webkit-transform: translate(-50%, -50%) rotate(405deg);\r\n  }\r\n}\r\n\r\n@keyframes img-rotate {\r\n  from {\r\n    transform: rotate(-45deg);\r\n  }\r\n  to {\r\n    transform: rotate(-405deg);\r\n  }\r\n}\r\n\r\n@-webkit-keyframes img-rotate {\r\n  from {\r\n    -webkit-transform: rotate(-45deg);\r\n  }\r\n  to {\r\n    -webkit-transform: rotate(-405deg);\r\n  }\r\n}"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./src/popup/popup.css":
/*!*****************************!*\
  !*** ./src/popup/popup.css ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_popup_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../../node_modules/css-loader/dist/cjs.js!./popup.css */ "./node_modules/css-loader/dist/cjs.js!./src/popup/popup.css");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_popup_css__WEBPACK_IMPORTED_MODULE_1__["default"], options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_popup_css__WEBPACK_IMPORTED_MODULE_1__["default"].locals || {});

/***/ }),

/***/ "./src/popup/popup.tsx":
/*!*****************************!*\
  !*** ./src/popup/popup.tsx ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-dom */ "./node_modules/react-dom/index.js");
/* harmony import */ var _popup_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./popup.css */ "./src/popup/popup.css");



const App = () => {
    return (react__WEBPACK_IMPORTED_MODULE_0__.createElement(react__WEBPACK_IMPORTED_MODULE_0__.Fragment, null,
        react__WEBPACK_IMPORTED_MODULE_0__.createElement(Loader, null)));
};
/////////////////////////animatedcircel///////////////////////////
const AnimatedCircle = () => {
    return (react__WEBPACK_IMPORTED_MODULE_0__.createElement(react__WEBPACK_IMPORTED_MODULE_0__.Fragment, null,
        react__WEBPACK_IMPORTED_MODULE_0__.createElement(Header, null),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("section", { className: "main-container" },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "animated-main " },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "big-circle" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "icon-block" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", { xmlns: "http://www.w3.org/2000/svg", width: "16", height: "16", fill: "currentColor", className: "bi bi-gear-wide-connected", viewBox: "0 0 16 16" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", { d: "M7.068.727c.243-.97 1.62-.97 1.864 0l.071.286a.96.96 0 0 0 1.622.434l.205-.211c.695-.719 1.888-.03 1.613.931l-.08.284a.96.96 0 0 0 1.187 1.187l.283-.081c.96-.275 1.65.918.931 1.613l-.211.205a.96.96 0 0 0 .434 1.622l.286.071c.97.243.97 1.62 0 1.864l-.286.071a.96.96 0 0 0-.434 1.622l.211.205c.719.695.03 1.888-.931 1.613l-.284-.08a.96.96 0 0 0-1.187 1.187l.081.283c.275.96-.918 1.65-1.613.931l-.205-.211a.96.96 0 0 0-1.622.434l-.071.286c-.243.97-1.62.97-1.864 0l-.071-.286a.96.96 0 0 0-1.622-.434l-.205.211c-.695.719-1.888.03-1.613-.931l.08-.284a.96.96 0 0 0-1.186-1.187l-.284.081c-.96.275-1.65-.918-.931-1.613l.211-.205a.96.96 0 0 0-.434-1.622l-.286-.071c-.97-.243-.97-1.62 0-1.864l.286-.071a.96.96 0 0 0 .434-1.622l-.211-.205c-.719-.695-.03-1.888.931-1.613l.284.08a.96.96 0 0 0 1.187-1.186l-.081-.284c-.275-.96.918-1.65 1.613-.931l.205.211a.96.96 0 0 0 1.622-.434l.071-.286zM12.973 8.5H8.25l-2.834 3.779A4.998 4.998 0 0 0 12.973 8.5zm0-1a4.998 4.998 0 0 0-7.557-3.779l2.834 3.78h4.723zM5.048 3.967c-.03.021-.058.043-.087.065l.087-.065zm-.431.355A4.984 4.984 0 0 0 3.002 8c0 1.455.622 2.765 1.615 3.678L7.375 8 4.617 4.322zm.344 7.646.087.065-.087-.065z" }))),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "icon-block" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", { xmlns: "http://www.w3.org/2000/svg", width: "16", height: "16", fill: "currentColor", className: "bi bi-file-lock", viewBox: "0 0 16 16" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", { d: "M8 5a1 1 0 0 1 1 1v1H7V6a1 1 0 0 1 1-1zm2 2.076V6a2 2 0 1 0-4 0v1.076c-.54.166-1 .597-1 1.224v2.4c0 .816.781 1.3 1.5 1.3h3c.719 0 1.5-.484 1.5-1.3V8.3c0-.627-.46-1.058-1-1.224zM6.105 8.125A.637.637 0 0 1 6.5 8h3a.64.64 0 0 1 .395.125c.085.068.105.133.105.175v2.4c0 .042-.02.107-.105.175A.637.637 0 0 1 9.5 11h-3a.637.637 0 0 1-.395-.125C6.02 10.807 6 10.742 6 10.7V8.3c0-.042.02-.107.105-.175z" }),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", { d: "M4 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H4zm0 1h8a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V2a1 1 0 0 1 1-1z" }))),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "icon-block" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", { xmlns: "http://www.w3.org/2000/svg", width: "16", height: "16", fill: "currentColor", className: "bi bi-pc", viewBox: "0 0 16 16" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", { d: "M5 0a1 1 0 0 0-1 1v14a1 1 0 0 0 1 1h6a1 1 0 0 0 1-1V1a1 1 0 0 0-1-1H5Zm.5 14a.5.5 0 1 1 0 1 .5.5 0 0 1 0-1Zm2 0a.5.5 0 1 1 0 1 .5.5 0 0 1 0-1ZM5 1.5a.5.5 0 0 1 .5-.5h5a.5.5 0 0 1 0 1h-5a.5.5 0 0 1-.5-.5ZM5.5 3h5a.5.5 0 0 1 0 1h-5a.5.5 0 0 1 0-1Z" }))),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "icon-block" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", { xmlns: "http://www.w3.org/2000/svg", width: "16", height: "16", fill: "currentColor", className: "bi bi-key", viewBox: "0 0 16 16" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", { d: "M0 8a4 4 0 0 1 7.465-2H14a.5.5 0 0 1 .354.146l1.5 1.5a.5.5 0 0 1 0 .708l-1.5 1.5a.5.5 0 0 1-.708 0L13 9.207l-.646.647a.5.5 0 0 1-.708 0L11 9.207l-.646.647a.5.5 0 0 1-.708 0L9 9.207l-.646.647A.5.5 0 0 1 8 10h-.535A4 4 0 0 1 0 8zm4-3a3 3 0 1 0 2.712 4.285A.5.5 0 0 1 7.163 9h.63l.853-.854a.5.5 0 0 1 .708 0l.646.647.646-.647a.5.5 0 0 1 .708 0l.646.647.646-.647a.5.5 0 0 1 .708 0l.646.647.793-.793-1-1h-6.63a.5.5 0 0 1-.451-.285A3 3 0 0 0 4 5z" }),
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", { d: "M4 8a1 1 0 1 1-2 0 1 1 0 0 1 2 0z" })))),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "circle" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "icon-block" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", { xmlns: "http://www.w3.org/2000/svg", width: "16", height: "16", fill: "currentColor", className: "bi bi-pc-display-horizontal", viewBox: "0 0 16 16" },
                            react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", { d: "M1.5 0A1.5 1.5 0 0 0 0 1.5v7A1.5 1.5 0 0 0 1.5 10H6v1H1a1 1 0 0 0-1 1v3a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-3a1 1 0 0 0-1-1h-5v-1h4.5A1.5 1.5 0 0 0 16 8.5v-7A1.5 1.5 0 0 0 14.5 0h-13Zm0 1h13a.5.5 0 0 1 .5.5v7a.5.5 0 0 1-.5.5h-13a.5.5 0 0 1-.5-.5v-7a.5.5 0 0 1 .5-.5ZM12 12.5a.5.5 0 1 1 1 0 .5.5 0 0 1-1 0Zm2 0a.5.5 0 1 1 1 0 .5.5 0 0 1-1 0ZM1.5 12h5a.5.5 0 0 1 0 1h-5a.5.5 0 0 1 0-1ZM1 14.25a.25.25 0 0 1 .25-.25h5.5a.25.25 0 1 1 0 .5h-5.5a.25.25 0 0 1-.25-.25Z" }))),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "icon-block" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://ucarecdn.com/2323ebfc-5b14-47ae-959a-191e82d0103a/blockchainicon.png", alt: "blockchain icon" })),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "icon-block" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://ucarecdn.com/5e4802ac-8684-41f3-8657-1e0834d07abe/arvricon.png", alt: "ar-vr icon" })),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "icon-block" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "https://ucarecdn.com/61a82adc-7eef-4e50-a7d5-8e11ef76ff31/artificialintelligenceicon.png", alt: "artificial intelligence icon" }))),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "center-logo" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("svg", { xmlns: "http://www.w3.org/2000/svg", width: "16", height: "16", fill: "currentColor", className: "bi bi-shield-fill-plus", viewBox: "0 0 16 16" },
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("path", { "fill-rule": "evenodd", d: "M8 0c-.69 0-1.843.265-2.928.56-1.11.3-2.229.655-2.887.87a1.54 1.54 0 0 0-1.044 1.262c-.596 4.477.787 7.795 2.465 9.99a11.777 11.777 0 0 0 2.517 2.453c.386.273.744.482 1.048.625.28.132.581.24.829.24s.548-.108.829-.24a7.159 7.159 0 0 0 1.048-.625 11.775 11.775 0 0 0 2.517-2.453c1.678-2.195 3.061-5.513 2.465-9.99a1.541 1.541 0 0 0-1.044-1.263 62.467 62.467 0 0 0-2.887-.87C9.843.266 8.69 0 8 0zm-.5 5a.5.5 0 0 1 1 0v1.5H10a.5.5 0 0 1 0 1H8.5V9a.5.5 0 0 1-1 0V7.5H6a.5.5 0 0 1 0-1h1.5V5z" }))))),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { style: { marginTop: "25px" } },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("h3", { className: "extHeading", style: { fontSize: "15px" } }, "Your are safe from Youtube,Twitch,And Malicious ads"),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("h3", { className: "extHeading" }, "Keep Browsing "))));
};
const Header = (props) => {
    return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "header" },
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", null,
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "./TrueAdBlocker128x128.png", alt: "", height: "80px" })),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", null,
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("h1", null, props.title))));
};
const Loader = () => {
    const [isActiveYoutube, setIsActiveYoutube] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(true);
    const [isConnecting, setisConnecting] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        const storedData = localStorage.getItem("appData");
        if (storedData) {
            const parsedData = JSON.parse(storedData);
            setIsActiveYoutube(parsedData.isActiveYoutube);
        }
    }, []);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
        const dataToStore = { isActiveYoutube };
        localStorage.setItem("appData", JSON.stringify(dataToStore));
    }, [isActiveYoutube]);
    //////////////////////////////////
    const tunOffAdBlc = () => {
        setIsActiveYoutube(!isActiveYoutube);
        setisConnecting(true);
        setTimeout(() => {
            setisConnecting(false);
            // Code to handle turning on ad blocking
        }, 2000);
        const message = { message: true };
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            const activeTab = tabs[0];
            if (activeTab) {
                chrome.tabs.sendMessage(activeTab.id, message, (response) => {
                    if (response && response.farewell) {
                        console.log(response.farewell, "response");
                    }
                });
            }
        });
    };
    const turnOnAdBlc = () => {
        setIsActiveYoutube(!isActiveYoutube);
        const message = { message: false };
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            const activeTab = tabs[0];
            if (activeTab) {
                chrome.tabs.sendMessage(activeTab.id, message, (response) => {
                    if (response && response.farewell) {
                        console.log(response.farewell, "response");
                    }
                });
            }
        });
    };
    /////////////////////////////////
    return (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", null, isActiveYoutube === false ? (react__WEBPACK_IMPORTED_MODULE_0__.createElement(react__WEBPACK_IMPORTED_MODULE_0__.Fragment, null,
        react__WEBPACK_IMPORTED_MODULE_0__.createElement(Header, { title: "TrueAdBlocker" }),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { style: { marginTop: "45px" } },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("h3", { className: "extHeading", style: { fontSize: "25px" } }, "Connect to Block Ads On"),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("h2", { className: "extHeading" }, "Youtube,Twitch,And Malicious ads ")),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "main", onClick: tunOffAdBlc },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { id: "ConnectionButton", className: "disconnected" },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "staticOuterCircle" }),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "staticInnerCircle" }),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "staticBackground" }),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: "title" }, "Connect"))))) : (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "main-connecting" }, isConnecting ? (react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "loading-container" },
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "loading" }),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { id: "loading-text" }, "Connecting..."))) : (react__WEBPACK_IMPORTED_MODULE_0__.createElement(react__WEBPACK_IMPORTED_MODULE_0__.Fragment, null, isActiveYoutube ? react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "main-dis" },
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "main-disconnect" },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { id: "ConnectionButton", className: "connected", onClick: turnOnAdBlc },
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "staticOuterCircle" }),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "staticInnerCircle" }),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "staticBackground" }),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", { className: "title" }, "Stop"))),
        react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "features" },
            react__WEBPACK_IMPORTED_MODULE_0__.createElement(AnimatedCircle, null),
            react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { style: { padding: "0px 10px 0px 10px" } },
                "       ",
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "youtube" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("h4", null, "YouTube"),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null,
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "./youtube.png" }),
                        " ")),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "twitch" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("h4", null, "Twitch"),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null,
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "./twitch.png" }),
                        " ")),
                react__WEBPACK_IMPORTED_MODULE_0__.createElement("div", { className: "twitch" },
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("h4", null, "malicious ads"),
                    react__WEBPACK_IMPORTED_MODULE_0__.createElement("span", null,
                        react__WEBPACK_IMPORTED_MODULE_0__.createElement("img", { src: "./malicious.png" }),
                        " "))))) : ""))))));
};
const root = document.createElement("div");
document.body.appendChild(root);
react_dom__WEBPACK_IMPORTED_MODULE_1__.render(react__WEBPACK_IMPORTED_MODULE_0__.createElement(App, null), root);


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			id: moduleId,
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = __webpack_modules__;
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/chunk loaded */
/******/ 	(() => {
/******/ 		var deferred = [];
/******/ 		__webpack_require__.O = (result, chunkIds, fn, priority) => {
/******/ 			if(chunkIds) {
/******/ 				priority = priority || 0;
/******/ 				for(var i = deferred.length; i > 0 && deferred[i - 1][2] > priority; i--) deferred[i] = deferred[i - 1];
/******/ 				deferred[i] = [chunkIds, fn, priority];
/******/ 				return;
/******/ 			}
/******/ 			var notFulfilled = Infinity;
/******/ 			for (var i = 0; i < deferred.length; i++) {
/******/ 				var [chunkIds, fn, priority] = deferred[i];
/******/ 				var fulfilled = true;
/******/ 				for (var j = 0; j < chunkIds.length; j++) {
/******/ 					if ((priority & 1 === 0 || notFulfilled >= priority) && Object.keys(__webpack_require__.O).every((key) => (__webpack_require__.O[key](chunkIds[j])))) {
/******/ 						chunkIds.splice(j--, 1);
/******/ 					} else {
/******/ 						fulfilled = false;
/******/ 						if(priority < notFulfilled) notFulfilled = priority;
/******/ 					}
/******/ 				}
/******/ 				if(fulfilled) {
/******/ 					deferred.splice(i--, 1)
/******/ 					var r = fn();
/******/ 					if (r !== undefined) result = r;
/******/ 				}
/******/ 			}
/******/ 			return result;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/jsonp chunk loading */
/******/ 	(() => {
/******/ 		// no baseURI
/******/ 		
/******/ 		// object to store loaded and loading chunks
/******/ 		// undefined = chunk not loaded, null = chunk preloaded/prefetched
/******/ 		// [resolve, reject, Promise] = chunk loading, 0 = chunk loaded
/******/ 		var installedChunks = {
/******/ 			"popup": 0
/******/ 		};
/******/ 		
/******/ 		// no chunk on demand loading
/******/ 		
/******/ 		// no prefetching
/******/ 		
/******/ 		// no preloaded
/******/ 		
/******/ 		// no HMR
/******/ 		
/******/ 		// no HMR manifest
/******/ 		
/******/ 		__webpack_require__.O.j = (chunkId) => (installedChunks[chunkId] === 0);
/******/ 		
/******/ 		// install a JSONP callback for chunk loading
/******/ 		var webpackJsonpCallback = (parentChunkLoadingFunction, data) => {
/******/ 			var [chunkIds, moreModules, runtime] = data;
/******/ 			// add "moreModules" to the modules object,
/******/ 			// then flag all "chunkIds" as loaded and fire callback
/******/ 			var moduleId, chunkId, i = 0;
/******/ 			if(chunkIds.some((id) => (installedChunks[id] !== 0))) {
/******/ 				for(moduleId in moreModules) {
/******/ 					if(__webpack_require__.o(moreModules, moduleId)) {
/******/ 						__webpack_require__.m[moduleId] = moreModules[moduleId];
/******/ 					}
/******/ 				}
/******/ 				if(runtime) var result = runtime(__webpack_require__);
/******/ 			}
/******/ 			if(parentChunkLoadingFunction) parentChunkLoadingFunction(data);
/******/ 			for(;i < chunkIds.length; i++) {
/******/ 				chunkId = chunkIds[i];
/******/ 				if(__webpack_require__.o(installedChunks, chunkId) && installedChunks[chunkId]) {
/******/ 					installedChunks[chunkId][0]();
/******/ 				}
/******/ 				installedChunks[chunkId] = 0;
/******/ 			}
/******/ 			return __webpack_require__.O(result);
/******/ 		}
/******/ 		
/******/ 		var chunkLoadingGlobal = self["webpackChunkreact_chrome_extension"] = self["webpackChunkreact_chrome_extension"] || [];
/******/ 		chunkLoadingGlobal.forEach(webpackJsonpCallback.bind(null, 0));
/******/ 		chunkLoadingGlobal.push = webpackJsonpCallback.bind(null, chunkLoadingGlobal.push.bind(chunkLoadingGlobal));
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/nonce */
/******/ 	(() => {
/******/ 		__webpack_require__.nc = undefined;
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module depends on other loaded chunks and execution need to be delayed
/******/ 	var __webpack_exports__ = __webpack_require__.O(undefined, ["vendors-node_modules_css-loader_dist_runtime_api_js-node_modules_css-loader_dist_runtime_cssW-1b44d9"], () => (__webpack_require__("./src/popup/popup.tsx")))
/******/ 	__webpack_exports__ = __webpack_require__.O(__webpack_exports__);
/******/ 	
/******/ })()
;
//# sourceMappingURL=popup.js.map